<div class="container">
  <div class="row">
    <div class="container" id="container">
      <div class="row">
        <div class="col-md-4 mb-3">
        <a  href="administrativo.php?link=1" class="btn btn-default navbar-btn pull-right"> <img src="img/obreiro.png" alt="#"><br>  Obreiros(as)   </a>
        </div>
        <div class="col-md-4 mb-3">
          <a href="administrativo.php?link=6" class="btn btn-default navbar-btn pull-right"> <img src="img/devocional.png" alt="#"><br>  Devocional </a>
        </div>
        <div class="col-md-4 mb-3">
          <a href="administrativo.php?link=10" class="btn btn-default navbar-btn pull-right"> <img src="img/banner.png" alt="#"><br> Banner </a>
        </div>
        <div class="col-md-4 mb-3">
          <a href="administrativo.php?link=13" class="btn btn-default navbar-btn pull-right"> <img src="img/banner.png" alt="#"><br> Imagens </a>
        </div>
        <div class="col-md-4 mb-3">
        <a href="administrativo.php?link=18" class="btn btn-default navbar-btn pull-right"> <img src="img/diaculto.png" alt="#"><br>  Dias de culto </a>
        </div>
        <div class="col-md-4 mb-3">
        <a href="administrativo.php?link=16" class="btn btn-default navbar-btn pull-right"> <img src="img/localizacao.png" alt="#"><br>  Localização </a>
        </div>
      </div>
    </div>
  </div>
</div>
