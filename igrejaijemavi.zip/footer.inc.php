<footer>
	<!-- <div class="social-icons">
	<a href="#"> <i class="fab fa-facebook-square"></i></a>
	<a href="#"> <i class="fab fa-twitter-square"></i></a>
	<a href="#"> <i class="fab fa-instagram"></i></a>
	<a href="#"> <i class="fab fa-google-plus-square"></i></a>
	<a href="#"> <i class="fa fa-envelope"></i></a>
		</div> -->
</footer>
