	<header id="header">
		<nav class="navbar navbar-expand-lg  navbar-light  bg-primary" >
			<a class="logo" href="index.php"> <img src="img/logo.png" alt="IJEMAVI"></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>


		  <div class="collapse navbar-collapse" id="navbarSupportedContent"><div  id="linhamenu"></div>
		    <ul class="navbar-nav mr-auto">
		      <li  class="nav-item active">
		        <a class="nav-link" href="#"> <label class="link">Galeria Imagens </label></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="devocional.php"><label class="link">Devocional</label></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="#"><label class="link">Contato</label></a>
		      </li>

					<li class="nav-item">
						<a  class="nav-link" href="doacoes.php#Doa"> Doações </a>
					</li>
					<li class="nav-item">
						<a  class="nav-link" href="diaculto.php" > Dias de culto </a>
					</li>

		    </ul>

				<div id="link_area_restrita" class="text-right">
					<a href="restrito.php" ><button type="button"  class="btn btn-sm btn-dark"> Área Restrita </button></a>
				</div>

		  </div>
		</nav>

	</header >
